package com.caltech.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommerceSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommerceSpringBootApplication.class, args);
	}

}
